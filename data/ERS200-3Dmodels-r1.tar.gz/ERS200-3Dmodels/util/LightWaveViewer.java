//
// Copyright 2002 Sony Corporation 
//
// Permission to use, copy, modify, and redistribute this software for
// non-commercial use is hereby granted.
//
// This software is provided "as is" without warranty of any kind,
// either expressed or implied, including but not limited to the
// implied warranties of fitness for a particular purpose.
//

import java.applet.*;
import java.awt.*;

import javax.vecmath.Point3d;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.TransformGroup;
import javax.media.j3d.BoundingSphere;

import com.sun.j3d.loaders.lw3d.Lw3dLoader;
import com.sun.j3d.loaders.Loader;
import com.sun.j3d.loaders.Scene;
import com.sun.j3d.utils.applet.MainFrame;
import com.sun.j3d.utils.universe.SimpleUniverse;
import com.sun.j3d.utils.behaviors.mouse.*;

public class LightWaveViewer extends Applet {

    private java.net.URL filename;
    private Scene loaderScene = null;

    public LightWaveViewer(java.net.URL url) {
        filename = url;
    }

    public void init() {
        Loader lw3dLoader = new Lw3dLoader(Loader.LOAD_ALL);
        Scene loaderScene = null;
        try {
            loaderScene = lw3dLoader.load(filename);
        }
        catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

        setLayout(new BorderLayout());
        GraphicsConfiguration config =
            SimpleUniverse.getPreferredConfiguration();
	    
        Canvas3D canvas = new Canvas3D(config);
        add("Center", canvas);

        SimpleUniverse universe = new SimpleUniverse(canvas);
        universe.getViewingPlatform().setNominalViewingTransform();

        BranchGroup sceneRoot = createSceneGraph(loaderScene);
        universe.addBranchGraph(sceneRoot);
    }

    private BranchGroup createSceneGraph(Scene scene) {
        BranchGroup root = new BranchGroup();

        TransformGroup trans = new TransformGroup();
        trans.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
        trans.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
  
        BoundingSphere bounds = new BoundingSphere(new Point3d(), 100.0);
      
        MouseRotate rotator = new MouseRotate(trans);
        rotator.setSchedulingBounds(bounds);
        root.addChild(rotator);
      
        MouseTranslate translator = new MouseTranslate(trans);
        translator.setSchedulingBounds(bounds);
        root.addChild(translator);
      
        MouseZoom zoomer = new MouseZoom(trans);
        zoomer.setSchedulingBounds(bounds);
        root.addChild(zoomer);

        if (scene.getSceneGroup() != null) {
            trans.addChild(scene.getSceneGroup());
            root.addChild(trans);
        }

        return root;
    }

    public static void main(String[] args) {
        java.net.URL url = null;

        if (args.length > 0) {
            try {
                if ((args[0].indexOf("file:") == 0) ||
                    (args[0].indexOf("http") == 0)) {
                    url = new java.net.URL(args[0]);
                }
                else if (args[0].charAt(0) != '/') {
                    url = new java.net.URL("file:./" + args[0]);
                }
                else {
                    url = new java.net.URL("file:" + args[0]);
                }
            }
            catch (java.net.MalformedURLException ex) {
                System.err.println(ex.getMessage());
                ex.printStackTrace();
                System.exit(1);
            }
        }
        else {
            System.err.println("usage: java LightWaveViewer file.lws");
            System.exit(1);
        }
	
        new MainFrame(new LightWaveViewer(url), 500, 500);
    }
}
