
                        ERS-7 3D model data


- Directory Tree

  ERS7-3Dmodel --+-- ERS-7 -- +-- LW --+-- Objects (.lwo)
                 |                     +-- Scenes  (.lws)
                 |
                 +--- util ----+-- LightWaveViewer.java

  LW : LightWave5.6 format files


- How to use LightWaveViewer 

  0. You need to install Java3D. 
     You can find more information about Java3D at one of these websites:

       http://java.sun.com/         (Windows)
       http://www.blackdown.org/    (Linux)     

  1. Compile LightWaveViewer.java 

     $ javac -d ERS-7/LW util/LightWaveViewer.java

  2. Execute LightWaveViewer

     $ cd ERS-7/LW
     $ java LightWaveViewer Scenes/ERS-7.lws
